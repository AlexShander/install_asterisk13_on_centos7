<div id="content"></div>

</div>

<div id="footer">
	<div id="footer-box">
		<a target="_blank" href="https://github.com/prog-it/Asterisk-CDR-Viewer-Mod">Asterisk CDR Viewer Mod v<?php echo VERSION; ?></a>
		<div title="Проверить обновления" id="check-updates"></div>
	</div>
</div>
</div>

<div id="scroll-box">
	<div id="scroll-up" class="scroll">&#9650;</div>
	<div id="scroll-down" class="scroll">&#9660;</div>
</div>

</body>
</html>
